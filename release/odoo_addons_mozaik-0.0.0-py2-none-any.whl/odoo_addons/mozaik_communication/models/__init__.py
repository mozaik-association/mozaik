from . import mass_mailing_stats
from . import virtual_models
from . import email_template
from . import mail_mass_mailing_group
from . import mail_mass_mailing
from . import mass_mailing_report
from . import email_template_placeholder

from . import models
from . import res_country
from . import address_local_street
from . import address_address
from . import res_partner
from . import reports
from . import wizard

from . import models
from . import res_partner
from . import wizard

from . import partner_involvement
from . import res_partner

from . import test_res_partner
from . import test_create_user_from_partner
from . import test_partner_involvement

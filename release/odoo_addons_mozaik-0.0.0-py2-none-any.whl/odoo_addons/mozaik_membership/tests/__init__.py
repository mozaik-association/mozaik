from . import test_structure
from . import test_membership
from . import test_partner
from . import test_product
from . import test_waiting_member_report
from . import test_force_int_instance
from . import test_postal_coordinate
from . import test_involvement
